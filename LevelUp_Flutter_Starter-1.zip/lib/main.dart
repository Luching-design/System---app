
import 'package:flutter/material.dart';

void main() {
  runApp(const LevelUpApp());
}

class LevelUpApp extends StatelessWidget {
  const LevelUpApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Level Up',
      theme: ThemeData.dark(),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("LEVEL UP")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Level 1", style: TextStyle(fontSize: 28)),
            const SizedBox(height: 12),
            const LinearProgressIndicator(value: 0.35),
            const SizedBox(height: 24),
            const Text("Daily Quests", style: TextStyle(fontSize: 22)),
            const SizedBox(height: 12),
            quest("20 Push-ups", true),
            quest("30 Squats", false),
            quest("1 km Run", false),
          ],
        ),
      ),
    );
  }

  Widget quest(String title, bool done) {
    return Card(
      child: ListTile(
        leading: Icon(
          done ? Icons.check_circle : Icons.radio_button_unchecked,
        ),
        title: Text(title),
      ),
    );
  }
}
