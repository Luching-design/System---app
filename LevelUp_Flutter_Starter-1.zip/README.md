# Level Up

Solo-Leveling-inspired self-improvement app starter.

Features planned:
- XP and leveling system
- Daily quests
- Workout categories
- Streaks
- Achievements
- Character stats
